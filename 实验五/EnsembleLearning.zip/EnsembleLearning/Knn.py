# coding=utf-8
import time

import numpy as np
import math

from TestDic import load_old


class Data_my:
    """
    专门用于KNN随机采样的类
    """
    vertex = np.zeros(3072)
    label = 0

    def __init__(self, vertex, label):
        self.vertex = vertex
        self.label = label


class Category:
    """
    距离代表训练点与测试点之间的距离
    label是训练点所属的类别
    """
    distance = 0
    lable = 0

    def __init__(self, distance, label):
        self.distance = distance
        self.lable = label


def get_category(train_data, train_data_labels, x, k):
    """"
    train_data训练的数据
    train_data_labels训练数据的类别
    x输入的数据
    k近邻的个数
    """
    categorys = []
    a = []
    for i in range(len(train_data)):
        categorys.append(Category(np.linalg.norm(x - train_data[i]),
                                  train_data_labels[i]))  # 求距离和标签
    categorys.sort(key=lambda x: x.distance)
    for i in range(k):
        a.append(categorys[i].lable)
    maxlabel = max(a, key=a.count)
    # print(maxlabel)
    return maxlabel


def test_knn():
    # 定义训练集——knn无需分为分为训练和验证
    images_data, labels = load_old('train')
    train_data = images_data[0:10000, :]
    train_labels = labels[:10000]
    # 定义测试集
    test_images_data, test_labels = load_old('test')
    test_data = test_images_data[0:1000, :]
    test_labels = test_labels[:1000]
    success = 0

    start = time.perf_counter()

    for i in range(len(test_data)):  # len(test_data)
        value = get_category(train_data, train_labels, test_data[i], 7)
        if value == test_labels[i]:
            success = success + 1
    end = time.perf_counter()
    print("算法的运行时间为：" + str(end - start))
    print("准确率为" + str(success / len(test_data)))


def get_knn(test_data, test_label, k):
    ls = []
    # 定义训练集——knn无需分为分为训练和验证
    images_data, labels = load_old('train')
    # 对训练集进行又放回的随机抽样
    lss = []
    for i in range(len(images_data)):
        lss.append(Data_my(images_data[i], labels[i]))
    train_data_my = np.random.choice(lss, size=10000, replace=True)
    train_data = []
    train_labels = []
    for i in range(len(train_data_my)):
        train_data.append(train_data_my[i].vertex)
        train_labels.append(train_data_my[i].label)
    train_data = np.array(train_data)
    train_labels = np.array(train_labels)
    # print(train_labels)
    for i in range(len(test_data)):  # len(test_data)
        value = get_category(train_data, train_labels, test_data[i], k)
        ls.append(value)

    success = 0
    for i in range(len(test_data)):
        if ls[i] == test_label[i]:
            success += 1
    print("knn算法的准确率为：" + str(success / len(test_data)))

    return ls


# 定义测试集
# start = time.perf_counter()
# test_images_data, test_labels = load_old('test')
# test_data = test_images_data[0:1000, :]
# test_labels = test_labels[:1000]
# values1 = get_knn(test_data, 7)
# success = 0
# for i in range(len(test_data)):
#     if test_labels[i] == values1[i]:
#         success += 1
# print("算法的成功率为：" + str(success / len(test_data)))
# end = time.perf_counter()
# print(end - start)
