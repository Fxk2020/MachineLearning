# coding=utf-8
import time

from BpNeuralNetworks import NeuralNetwork, get_bp
from Knn import get_category, get_knn
from SVM_kernel import get_svm
from TestDic import load_old, load


def get_testData():
    # 定义测试集
    test_images_data, test_labels = load_old('test')
    test_data = test_images_data[0:1000, :]
    test_labels = test_labels[:1000]
    return test_data, test_labels


def bagging():
    test_data, test_labels = get_testData()
    success = 0

    # # 1.神经网络模型-对测试集类型的判断
    values1 = get_bp(test_data, test_labels,0.05, 25)
    values1_2 = get_bp(test_data, test_labels,0.01, 25)
    values1_3 = get_bp(test_data, test_labels,0.03, 25)

    # # 2.svm模型-对测试集类型的判断
    values2 = get_svm(test_data, test_labels, 3.0, 3)
    values2_2 = get_svm(test_data, test_labels, 2.0, 2)
    values2_3 = get_svm(test_data, test_labels, 1.0, 4)
    # values2_4 = get_svm(test_data, test_labels, 3.0, 1)
    # values2_5 = get_svm(test_data, test_labels, 2.0, 3)
    # values2_6 = get_svm(test_data, test_labels, 1.0, 2)
    # values2_7 = get_svm(test_data, test_labels, 3.0, 3)
    # values2_8 = get_svm(test_data, test_labels, 2.0, 1)
    # values2_9 = get_svm(test_data, test_labels, 1.0, 5)
    # values2_10 = get_svm(test_data, test_labels, 3.0, 3)

    # 3.投票做出做出决策
    # values3 = get_knn(test_data, test_labels, 7)
    # values3_2 = get_knn(test_data, test_labels, 5)
    # values3_3 = get_knn(test_data, test_labels, 3)
    # values3_4 = get_knn(test_data, 1)
    # values3_5 = get_knn(test_data, 9)
    # values3_6 = get_knn(test_data, 1)
    # values3_7 = get_knn(test_data, 3)
    # values3_8 = get_knn(test_data, 5)
    # values3_9 = get_knn(test_data, 7)
    # values3_10 = get_knn(test_data, 9)

    # for i in range(len(test_data)):
    #     if values1[i] == values2[i]:
    #         value = values1[i]
    #     elif values1[i] == values3[i]:
    #         value = values1[i]
    #     elif values2[i] == values3[i]:
    #         value = values2[i]
    #     else:
    #         value = values2[i]  # 采用svm的分类方式进行分类
    #     if test_labels[i] == value:
    #         success += 1

    for i in range(len(test_data)):
        value = [values1[i], values1_2[i], values1_3[i], values2[i], values2_2[i], values2_3[i]]
        maxlabel = max(value, key=value.count)
        if maxlabel == test_labels[i]:
            success += 1

    print("集成学习算法的准确率为" + str(success / len(test_data)))


if __name__ == '__main__':
    start = time.perf_counter()
    bagging()
    end = time.perf_counter()
    print("算法的运行时间为：" + str(end - start))
