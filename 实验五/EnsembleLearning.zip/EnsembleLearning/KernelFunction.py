# coding=utf-8
import numpy as np
import matplotlib.pyplot as plt


# # 定义一个从-4到5分布的数值，分割间隔为1
# x = np.arange(-4, 5, 1)
# # 将-2到2之间的点归为一类，类别为1，将小于-2和大于2的点归为一类，类别为0
# y = np.array((x >= -2) & (x <= 2), dtype='int')
#
# # 可视化一下
# plt.scatter(x[y == 0], [0] * len(x[y == 0]))
# plt.scatter(x[y == 1], [0] * len(x[y == 1]))
# plt.show()


# 定义svm核函数的公式：
from TestDic import load


def kernelTrans(X, A, kTup):  # 通过数据计算转换后的核函数
    m, n = np.shape(X)
    K = np.mat(np.zeros((m, 1)))
    if kTup[0] == 'lin':  # 线性核函数
        K = X * A.T

    elif kTup[0] == 'rbf':  # 高斯核
        for j in range(m):
            deltaRow = X[j, :] - A
            K[j] = deltaRow * deltaRow.T
        K = np.exp(K / (-1 * kTup[1] ** 2))

    elif kTup[0] == 'laplace':  # 拉普拉斯核
        for j in range(m):
            deltaRow = X[j, :] - A
            K[j] = deltaRow * deltaRow.T
            K[j] = np.sqrt(K[j])
        K = np.exp(-K / kTup[1])

    elif kTup[0] == 'poly':  # 多项式核
        K = X * A.T
        for j in range(m):
            K[j] = K[j] ** kTup[1]

    elif kTup[0] == 'sigmoid':  # Sigmoid核
        K = X * A.T
        for j in range(m):
            K[j] = np.tanh(kTup[1] * K[j] + kTup[2])

    else:
        raise NameError('Houston We Have a Problem -- \
    That Kernel is not recognized')
    return K


def poly(X, A, n):
    m = X.shape[0]
    K = np.mat(np.zeros((m, m)))
    K = np.dot(X,  A.T)
    for i in range(m):
        for j in range(m):
            K[i][j] = K[i][j] ** n
    print(K.shape[0])
    print(K.shape[1])
    return K


# 定义训练集——分为训练和验证
images_data, labels = load('train')
verification_data = images_data[49000:50000, :]
train_data = images_data[0:4900, :]
verification_labels = labels[49000:50000, :]
train_labels = labels[0:49000, :]

X = []
for i in range(2):
    data_temp = np.zeros((len(train_data), len(train_data[0])))
    for j in range(len(train_data)):
        data_temp[j] = train_data[i] - train_data[j]
    X.append(data_temp)
print(poly(X[0], X[1], 2))
# x = np.arange(-4, 5, 1)
# y = np.zeros(9)
# X = []
# for i in range(len(x)):
#     x_temp = np.zeros(9)
#     for j in range(len(x)):
#         x_temp[j] = np.abs(x[i] - x[j])
#     print(x_temp)
#     X.append(x_temp)
# print(X[0])
#
# print(poly(X[0], X[1], 2))
#
# K = poly(X[0], X[1], 4)
# plt.scatter(x, K)
# plt.show()