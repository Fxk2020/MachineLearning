# coding=utf-8
import time

import numpy

#  定义numNeuronLayers, numNeurons_perLayer，learningrate来初始化网络层数，每层神经元个数和学习率
from TestDic import load_old, load


class Data_my:
    """
    专门用来供BP神经网络随机抽样的类
    """
    vertex = numpy.zeros(3072)
    label = numpy.zeros(10)

    def __init__(self, vertex, label):
        self.vertex = vertex
        self.label = label


class NeuralNetwork:
    def __init__(self, numNeuronLayers, numNeurons_perLayer, learningrate):
        self.numNeurons_perLayer = numNeurons_perLayer
        self.numNeuronLayers = numNeuronLayers
        self.learningrate = learningrate
        self.weight = []
        self.bias = []
        # w和b的初始化
        for i in range(numNeuronLayers):
            self.weight.append(numpy.random.normal(0.0, pow(self.numNeurons_perLayer[i + 1], -0.5),
                                                   (self.numNeurons_perLayer[i + 1], self.numNeurons_perLayer[i])))
        for i in range(numNeuronLayers):
            self.bias.append(numpy.random.randn(numNeurons_perLayer[i + 1], 1))
        # print(self.weight[1].shape[1])
        # 另外的可行的激活函数
        # x: (numpy.exp(x) - numpy.exp(-x)) / (numpy.exp(x) + numpy.exp(-x))
        self.activation_function = lambda x: 1.0 / (1.0 + numpy.exp(-x))

    # 训练函数
    def update(self, input_nodes, targets):
        inputs = numpy.array(input_nodes, ndmin=2).T
        targets = numpy.array(targets, ndmin=2).T

        # 前向传播——关键在于计算出每层的损失
        # 定义输出值列表（outputs[0]为输入值）
        self.outputs = []
        self.outputs.append(inputs)
        # 将神经网络的每一层计算输出值作为输入放入激活函数中，并保存到outputs列表中
        for i in range(self.numNeuronLayers):
            # 每个神经元的输入信号z，由参数w、b，和前一层的输出信号a决定
            temp_inputs = numpy.dot(self.weight[i], inputs) + self.bias[i]
            temp_outputs = self.activation_function(temp_inputs)
            inputs = temp_outputs
            self.outputs.append(temp_outputs)
        # 计算每层的损失
        self.output_errors = []
        for i in range(self.numNeuronLayers):
            # 输出层的误差=目标值-输出值
            if i == 0:
                self.output_errors.append(targets - self.outputs[-1])
            # 隐藏层的误差=（当前隐藏层与下一层之间的权值矩阵）的转置与下一层的误差矩阵的乘积
            else:
                self.output_errors.append(numpy.dot((self.weight[self.numNeuronLayers - i]).T,
                                                    self.output_errors[i - 1]))
        # 反向传播
        for i in range(self.numNeuronLayers):
            # 权值更新规则为之前 新权值=权值+学习率*误差*激活函数的导数*上一层输出
            # 偏移量b的更新规则 新偏执因子=偏执因子+学习率*误差*激活函数的导数
            # f(x)*（1-f(x)）即为激活函数f(x)的导函数
            self.weight[self.numNeuronLayers - i - 1] += \
                self.learningrate * numpy.dot(
                    self.output_errors[i] * self.outputs[-1 - i] * (1 - self.outputs[-1 - i]),
                    self.outputs[-2 - i].T)
            self.bias[self.numNeuronLayers - i - 1] += self.learningrate * (
                    self.output_errors[i] * self.outputs[-1 - i] * (1 - self.outputs[-1 - i]))

    # 将测试用例作为输入，让模型走一遍前向传播过程得到输出,返回输出
    def test(self, test_inputnodes):
        inputs = numpy.array(test_inputnodes, ndmin=2).T
        # 走一遍前向传播得到输出
        for i in range(self.numNeuronLayers):
            temp_inputs = numpy.dot(self.weight[i], inputs) + self.bias[i]
            temp_outputs = self.activation_function(temp_inputs)
            inputs = temp_outputs
        # 返回模型输出结果是否与测试用例标签一致
        # 测试用例在模型中输出的是第几类：
        # print(list(inputs).index(max(list(inputs))))
        return list(inputs).index(max(list(inputs)))


def test_bp(learning_rate, cycles):
    # 定义训练集
    images_data, labels = load('train')
    train_data = images_data[0:10000, :]
    train_labels = labels[0:10000, :]
    # 定义测试集
    test_images_data, test_labels = load_old('test')
    test_data = test_images_data[0:1000, :]
    test_labels = test_labels[:1000]
    ls = [3072, 50, 10]

    start = time.perf_counter()

    # 神经网络的层数是从隐藏层开始计数的，输入层不计入总层数。
    n = NeuralNetwork(2, ls, learning_rate)
    for i in range(cycles):
        for j in range(len(train_data)):
            n.update(train_data[j], train_labels[j])  # 更新模型
    success = 0
    for i in range(len(test_data)):
        if n.test(test_data[i]) == test_labels[i]:
            success = success + 1
    end = time.perf_counter()
    print("算法的运行时间为：" + str(end - start))
    print("准确率为" + str(success / len(test_data)))


def get_bp(test_data, test_label, learning_rate, cycles):
    # 定义训练集
    images_data, labels = load('train')

    # 对训练集进行又放回的随机抽样
    ls = []
    for i in range(len(images_data)):
        ls.append(Data_my(images_data[i], labels[i]))
    train_data_my = numpy.random.choice(ls, size=10000, replace=True)

    value = []
    ls = [3072, 50, 10]
    # 神经网络的层数是从隐藏层开始计数的，输入层不计入总层数。
    n = NeuralNetwork(2, ls, learning_rate)
    for i in range(cycles):
        for j in range(len(train_data_my)):
            n.update(train_data_my[j].vertex, train_data_my[j].label)  # 更新模型
    for i in range(len(test_data)):
        value.append(n.test(test_data[i]))

    success = 0
    for i in range(len(test_data)):
        if value[i] == test_label[i]:
            success += 1
    print("bp神经网络的算法的准确率为：" + str(success / len(test_data)))

    return value


# test_bp(0.01, 5)
# 定义测试集
# start = time.perf_counter()
# test_images_data, test_labels = load_old('test')
# test_data = test_images_data[0:1000, :]
# test_labels = test_labels[:1000]
# values1 = get_bp(test_data, 0.05, 5)
# success = 0
# for i in range(len(test_data)):
#     if test_labels[i] == values1[i]:
#         success += 1
# print("算法的成功率为：" + str(success / len(test_data)))
# end = time.perf_counter()
# print(start - end)
