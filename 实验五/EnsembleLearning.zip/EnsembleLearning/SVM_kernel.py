import time

import numpy as np
import random
from sklearn import svm

from TestDic import load, load_old


class Data_my:
    """
    专门用于SVM随机采样的类
    """
    vertex = np.zeros(3072)
    label = 0

    def __init__(self, vertex, label):
        self.vertex = vertex
        self.label = label


class Svm:
    C = 1.0
    degree = 3
    clf = svm

    def __init__(self, C=1.0, kernel='poly', degree=3):
        """
        用参数对svm模型进行初始化
        :param C: 惩罚参数C用于缓解过拟合问题
        :param kernel:默认为高斯核函数
        :param degree:度，默认= 3 多项式核函数的度（“ poly”）
        """
        self.C = C
        self.degree = degree
        self.clf = svm.SVC(C=C, kernel=kernel, degree=degree)

    def update(self, train_data, train_label):
        """
        :param train_data: 训练集数据
        :param train_label: 训练集标签
        """
        self.clf.fit(train_data, train_label)

    def get_test_labels(self, test_data, test_label):
        """
        :param test_data: 测试数据集
        :param test_label: 测试标签集
        :return: 对测试数据的预测类别
        """
        # print(self.clf.score(test_data, test_label))  # 输出在测试集上的准确率
        return self.clf.predict(test_data)


def get_svm(test_data, test_label, C, degree):
    ls = []
    # 定义训练集——knn无需分为分为训练和验证
    images_data, labels = load_old('train')
    # 对训练集进行又放回的随机抽样
    lss = []
    for i in range(len(images_data)):
        lss.append(Data_my(images_data[i], labels[i]))
    train_data_my = np.random.choice(lss, size=10000, replace=True)
    train_data = []
    train_labels = []
    for i in range(len(train_data_my)):
        train_data.append(train_data_my[i].vertex)
        train_labels.append(train_data_my[i].label)
    train_data = np.array(train_data)
    train_labels = np.array(train_labels)
    svm_my = Svm(C=C, kernel='poly', degree=degree)  # kernel='poly',
    svm_my.update(train_data, train_labels)
    ls = svm_my.get_test_labels(test_data, test_label)

    success = 0
    for i in range(len(test_data)):
        if ls[i] == test_label[i]:
            success += 1
    print("svm算法的准确率为：" + str(success / len(test_data)))

    return ls

# start = time.perf_counter()
# test_images_data, test_labels = load_old('test')
# test_images_data = test_images_data[0:10000]
# test_labels = test_labels[:10000]
# value = get_svm(test_images_data, test_labels, 3.0, 3)
# success = 0
# for i in range(len(test_images_data)):
#     if value[i] == test_labels[i]:
#         success += 1
# print("算法的准确率为："+str(success / len(test_images_data)))
# end = time.perf_counter()
# print("算法的运行时间为："+str(end - start))
